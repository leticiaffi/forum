public class Conta {
    private double saldo;

    // atributos
    // métodos

    public boolean transfere(double valor, Conta destino) {
        if(this.saldo >= valor) {
            this.saldo -= valor;
            destino.deposita(valor);
            return true;
        } else {
            return false;
        }
    }

    private void deposita(double valor) {

    }
}
