public class Funcionario {

    private String nome;
    private String cpf;
    private double salario;

    public Funcionario() {

    }

    public void setNome(String nico_steppat) {
    }

    public void setCpf(String s) {
    }

    public void setSalario(double v) {
    }

    public boolean getNome() {
    }

    public boolean getBonificacao() {
    }

// Código continua embaixo...

